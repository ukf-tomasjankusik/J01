package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.layout.CornerRadii;
import javafx.geometry.Insets;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import javax.swing.*;



public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{


        TextField t1 = new TextField();
        Button b1 = new Button("Zadaj");
        Label l1 = new Label("");
        VBox root = new VBox();
        Scene scene = new Scene(root ,900, 900);
        scene.setFill(Color.GREEN);
        primaryStage.setTitle("xd");
        primaryStage.setScene(scene);
        b1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                String text = t1.getText();
                l1.setText("  "+text);
                t1.setText("");

                int pocet_sam = 0;
                int pocet_spol = 0;
                int R = 0;
                int G = 0;
                int B = (text.length() % 25)*10;

                for(int i = 0; i < text.length(); i++) {
                    if(text.charAt(i) == 'a' | text.charAt(i) == 'e' | text.charAt(i) == 'i' |
                            text.charAt(i) == 'o' | text.charAt(i) == 'u' | text.charAt(i) == 'y' | text.charAt(i) == 'ä') pocet_sam++;
                    else pocet_spol++;
                }

                R = pocet_sam * 16;
                G = pocet_spol * 24;
                if(R > 255) R=255;
                if(G > 255) G=255;
                if(B > 255) B=255;
                root.setBackground(new Background(new BackgroundFill(Color.rgb(R,G,B),null,null)));
            }
        });

        root.getChildren().addAll(t1,b1,l1);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
