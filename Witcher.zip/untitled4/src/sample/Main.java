package sample;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Group root = new Group();
        Scene scene = new Scene(root ,720, 406);

        Line line1 = new Line(100,170,140,170);
        line1.setStroke(Color.PURPLE);
        line1.setStrokeWidth(4);
        root.getChildren().add(line1);
        DropShadow glow6 = new DropShadow(100,Color.PURPLE);
        glow6.setSpread(0.90);
        line1.setEffect(glow6);

        Line line2 = new Line(100,170,140,220);
        line2.setStroke(Color.PURPLE);
        line2.setStrokeWidth(4);
        root.getChildren().add(line2);
        DropShadow glow = new DropShadow(100,Color.PURPLE);
        glow.setSpread(0.90);
        line2.setEffect(glow);

        Line line3 = new Line(100,220,140,220);
        line3.setStroke(Color.PURPLE);
        line3.setStrokeWidth(4);
        root.getChildren().add(line3);
        DropShadow glow7 = new DropShadow(100,Color.PURPLE);
        glow7.setSpread(0.90);
        line3.setEffect(glow7);

        Line line4 = new Line(100,220,110,209);
        line4.setStroke(Color.PURPLE);
        line4.setStrokeWidth(4);
        root.getChildren().add(line4);
        DropShadow glow8 = new DropShadow(100,Color.PURPLE);
        glow8.setSpread(0.90);
        line4.setEffect(glow8);

        Line line5 = new Line(140,170,127,187);
        line5.setStroke(Color.PURPLE);
        line5.setStrokeWidth(4);
        root.getChildren().add(line5);
        DropShadow glow9 = new DropShadow(100,Color.PURPLE);
        glow9.setSpread(0.90);
        line5.setEffect(glow9);

// **********************************************************************************

        Line line6 = new Line(220,170,270,170);
        line6.setStroke(Color.YELLOW);
        line6.setStrokeWidth(4);
        root.getChildren().add(line6);
        DropShadow glow10 = new DropShadow(100,Color.YELLOW);
        glow10.setSpread(0.90);
        line6.setEffect(glow10);

        Line line7 = new Line(220,170,240,220);
        line7.setStroke(Color.YELLOW);
        line7.setStrokeWidth(4);
        root.getChildren().add(line7);
        DropShadow glow2 = new DropShadow(100,Color.YELLOW);
        glow2.setSpread(0.90);
        line7.setEffect(glow2);

        Line line8 = new Line(240,220,250,206);
        line8.setStroke(Color.YELLOW);
        line8.setStrokeWidth(4);
        root.getChildren().add(line8);
        DropShadow glow11 = new DropShadow(100,Color.YELLOW);
        glow11.setSpread(0.90);
        line8.setEffect(glow11);

        Line line9 = new Line(270,170,260,189);
        line9.setStroke(Color.YELLOW);
        line9.setStrokeWidth(4);
        root.getChildren().add(line9);
        DropShadow glow12 = new DropShadow(100,Color.YELLOW);
        glow12.setSpread(0.90);
        line9.setEffect(glow12);

        Line line10 = new Line(260,189,245,189);
        line10.setStroke(Color.YELLOW);
        line10.setStrokeWidth(4);
        root.getChildren().add(line10);
        DropShadow glow13 = new DropShadow(100,Color.YELLOW);
        glow13.setSpread(0.90);
        line10.setEffect(glow13);

// **********************************************************************************

        Line line11 = new Line(340,220,390,220);
        line11.setStroke(Color.RED);
        line11.setStrokeWidth(4);
        root.getChildren().add(line11);
        DropShadow glow14 = new DropShadow(100,Color.RED);
        glow14.setSpread(0.90);
        line11.setEffect(glow14);

        Line line12 = new Line(340,220,365,170);
        line12.setStroke(Color.RED);
        line12.setStrokeWidth(4);
        root.getChildren().add(line12);
        DropShadow glow3 = new DropShadow(100,Color.RED);
        glow3.setSpread(0.90);
        line12.setEffect(glow3);

        Line line13 = new Line(390,220,374,194);
        line13.setStroke(Color.RED);
        line13.setStrokeWidth(4);
        root.getChildren().add(line13);
        DropShadow glow15 = new DropShadow(100,Color.RED);
        glow15.setSpread(0.90);
        line13.setEffect(glow15);

// **********************************************************************************

        Line line14 = new Line(460,170,515,170);
        line14.setStroke(Color.GREEN);
        line14.setStrokeWidth(4);
        root.getChildren().add(line14);
        DropShadow glow16 = new DropShadow(100,Color.GREEN);
        glow16.setSpread(0.90);
        line14.setEffect(glow16);

        Line line15 = new Line(460,170,486,220);
        line15.setStroke(Color.GREEN);
        line15.setStrokeWidth(4);
        root.getChildren().add(line15);
        DropShadow glow4 = new DropShadow(100,Color.GREEN);
        glow4.setSpread(0.90);
        line15.setEffect(glow4);

        Line line16 = new Line(486,220,505,191);
        line16.setStroke(Color.GREEN);
        line16.setStrokeWidth(4);
        root.getChildren().add(line16);
        DropShadow glow17 = new DropShadow(100,Color.GREEN);
        glow17.setSpread(0.90);
        line16.setEffect(glow17);

// **********************************************************************************
        Line line17 = new Line(580,220,635,220);
        line17.setStroke(Color.CYAN);
        line17.setStrokeWidth(4);
        root.getChildren().add(line17);
        DropShadow glow18 = new DropShadow(100,Color.CYAN);
        glow18.setSpread(0.90);
        line17.setEffect(glow18);

        Line line18 = new Line(635,220,607,170);
        line18.setStroke(Color.CYAN);
        line18.setStrokeWidth(4);
        root.getChildren().add(line18);
        DropShadow glow19 = new DropShadow(100,Color.CYAN);
        glow19.setSpread(0.90);
        line18.setEffect(glow19);

        Line line19 = new Line(607,170,597,187);
        line19.setStroke(Color.CYAN);
        line19.setStrokeWidth(4);
        root.getChildren().add(line19);
        DropShadow glow20 = new DropShadow(100,Color.CYAN);
        glow20.setSpread(0.90);
        line19.setEffect(glow20);

        Line line20 = new Line(580,220,590,205);
        line20.setStroke(Color.CYAN);
        line20.setStrokeWidth(4);
        root.getChildren().add(line20);
        DropShadow glow21 = new DropShadow(100,Color.CYAN);
        glow21.setSpread(0.90);
        line20.setEffect(glow21);

        Line line21 = new Line(590,205,605,205);
        line21.setStroke(Color.CYAN);
        line21.setStrokeWidth(4);
        root.getChildren().add(line21);
        DropShadow glow5 = new DropShadow(100,Color.CYAN);
        glow5.setSpread(0.90);
        line21.setEffect(glow5);


        scene.setFill(Color.BLACK);
        primaryStage.setTitle("Witcher");
        primaryStage.setScene(scene);
        primaryStage.show();

    }


    public static void main(String[] args) {
        launch(args);
    }
}
